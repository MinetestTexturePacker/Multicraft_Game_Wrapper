3D Armor - Visible Player Armor
===============================

Source Code: Copyright (C) 2013 Stuart Jones - LGPL

Special credit to Jordach and MirceaKitsune for providing the default 3d character model.

