A 3d character model re-texturing api used as the framework for this modpack.

depends: default

Compatible with player skins mod [skins] by Zeg9 and Player Textures [player_textures] by sdzen.

Note: Currently only 64x32px player skins.
