inventory_plus = {}

function inventory_plus.set_inventory_formspec(player, formspec)
end

function inventory_plus.register_button(player,str1, str2)
end