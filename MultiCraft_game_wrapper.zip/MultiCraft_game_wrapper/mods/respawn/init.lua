minetest.register_on_respawnplayer(function(player)
    player:setpos({x=177.15, y=-15, z=375.5})
    return true
end)
