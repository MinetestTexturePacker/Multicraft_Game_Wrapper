Minetest 0.4 mod: farming
=========================

License of source code:
-----------------------
Copyright (C) 2014 webdesigner97

            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
                    Version 2, December 2004

 Copyright (C) 2004 Sam Hocevar <sam@hocevar.net>

 Everyone is permitted to copy and distribute verbatim or modified
 copies of this license document, and changing it is allowed as long
 as the name is changed.

            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION

  0. You just DO WHAT THE FUCK YOU WANT TO. 

License of media (textures):
----------------------------
Created by PilzAdam (License: WTFPL):
  farming_bread.png
  farming_soil.png
  farming_soil_wet.png
  farming_soil_wet_side.png
  farming_string.png

Created by BlockMen (License: CC BY 3.0):
  farming_tool_diamondhoe.png
  farming_tool_mesehoe.png
  farming_tool_bronzehoe.png
  farming_tool_steelhoe.png
  farming_tool_stonehoe.png
  farming_tool_woodhoe.png

Created by MasterGollum (License: WTFPL):
  farming_straw.png

Created by Gambit (License: WTFPL):
  farming_wheat.png
  farming_wheat_*.png
  farming_cotton_*.png
  farming_flour.png
  farming_cotton_seed.png
  farming_wheat_seed.png