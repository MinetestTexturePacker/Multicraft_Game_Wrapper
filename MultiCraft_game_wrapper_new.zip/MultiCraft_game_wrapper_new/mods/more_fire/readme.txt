Put this folder into your Mods folder and enable.

This mod is using the newly added Mesh type so you need a recent build for it to work. If you are on linux consider using the daily build PPA or build from source.

If you have any ideas for more fire related things please let me know, or consider forking the project on GIT. I'm always ready to add more good stuff.

There is a bug where placing torches on a stone wall sometimes reacts strangly. If you put two torches next to each other one will usually fall off the wall. Not sure why...
